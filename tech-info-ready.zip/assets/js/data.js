export const categories = [
  { id: "one-to-one-call", name: "One to One Call" },
  { id: "ai-tools", name: "AI Tools" }
];